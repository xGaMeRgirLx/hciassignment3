# hciassignment3
This repository is for HCI assignemnt Nr. 3 task C
TODO maybe remove the keyboard--hidden feature
TODO: pop up for random length of symbols